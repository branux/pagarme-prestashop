<?php

class pagarmeprestashopValidationModuleFrontController extends ModuleFrontController
{

    public function postProcess()
    {
        $this->setTemplate('module:pagarmeprestashop/views/templates/front/boleto-payment.tpl');

    }
}