<?php
class PagarmeDisplayModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();
        $this->setTemplate('module:pagarmeprestashop/views/templates/front/display.tpl');
    }
}