<?php

if(!defined('_PS_VERSION_'))
{
    exit;
}
use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

class PagarmePrestaShop extends PaymentModule
{
    public function __construct()
    {
        $this->name = 'pagarmeprestashop';
        $this->tab = 'payments_gateways';
        $this->version = '2.0.0';
        $this->author = 'Aardvark Silva';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Pagar.me API module');
        $this->description = $this->l('Module integration to create transactions through Pagar.me API .');

        $this->confirmUninstall = $this->l('Are you sure that you want to uninstall the Pagar.me module?');

        if(!Configuration::get('MYMODULE_NAME'))
        {
            $this->warning = $this->l('No name provided');
        }
    }
    public function install()
    {
        if (Shop::isFeatureActive())
            Shop::setContext(Shop::CONTEXT_ALL);

        return parent::install() &&
            $this->registerHook('leftColumn') &&
            $this->registerHook('header') &&
            $this->registerHook('paymentOptions') &&
            $this->registerHook('paymentReturn') &&
            Configuration::updateValue('MYMODULE_NAME', 'Pagarme') &&
            Configuration::updateValue('API_KEY', 'YOURAPIKEY');
    }
    public function uninstall()
    {
        if(!parent::uninstall())
            return false;
        return true;
    }

    public function getContent()
    {
        $output = null;

        if(Tools::isSubmit('submit'.$this->name))
        {
            $api_key = strval(Tools::getValue('API_KEY'));
            if(!$api_key || empty($api_key))
                $output .= $this->displayError($this->l('You need an api key in order to process transactions'));
            else
            {
                Configuration::updateValue('API_KEY', $api_key);
                $output .= $this->displayConfirmation($this->l('Setting successfully configured for Pagarme module!'));
            }

        }
        return $output.$this->displayForm();
    }

    public function displayForm()
    {
        //Get the default language
        $default_language = (int)Configuration::get('PS_LANG_DEFAULT');

        //Init fields form array
        $fields_form[0]['form'] = array(
            'legend' => array(
                'title' => $this->l('Settings'),
            ),
            'input' => array(
                array(
                    'type' => 'text',
                    'label' => $this->l('Your Pagar.me API KEY'),
                    'name' => 'API_KEY',
                    'size' => 20,
                    'required' => true
                )
            ),
            'submit' => array(
                'title' => $this->l('Save'),
                'class' => 'btn btn-default pull-right'
            )
        );

        $helper = new HelperForm();

        // Module, token and currentIndex
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;

        // Language
        $helper->default_form_language = $default_language;
        $helper->allow_employee_form_lang = $default_language;

        // Title and toolbar
        $helper->title = $this->displayName;
        $helper->show_toolbar = true;        // false -> remove toolbar
        $helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
        $helper->submit_action = 'submit'.$this->name;
        $helper->toolbar_btn = array(
            'save' =>
            array(
                'desc' => $this->l('Save'),
                'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
                '&token='.Tools::getAdminTokenLite('AdminModules'),
            ),
            'back' => array(
                'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
                'desc' => $this->l('Back to list')
            )
        );
        // Load current value
        $helper->fields_value['API_KEY'] = Configuration::get('API_KEY');

        return $helper->generateForm($fields_form);
    }

    public function hookPaymentOptions($params)
    {
        return [$this->getBoletoPagarme($params)];
    }

    public function getBoletoPagarme($params)
    {
        $pagarme = new PaymentOption();
        $pagarme->setCallToActionText($this->l('Boleto Pagarme'))
            ->setForm($this->generateForm($params))
            ->setAdditionalInformation($this->context->smarty->fetch('module:pagarmeprestashop/views/templates/front/boleto-payment.tpl'));

        return $pagarme;
    }

    protected function generateForm($params)
    {
        $months = [];
        for ($i = 1; $i <= 12; $i++) {
            $months[] = sprintf("%02d", $i);
        }
        $years = [];
        for ($i = 0; $i <= 10; $i++) {
            $years[] = date('Y', strtotime('+'.$i.' years'));
        }
        $this->context->smarty->assign([
            'action' => $this->context->link->getModuleLink($this->name, 'validation', array(), true),
            'months' => $months,
            'years' => $years,
        ]);
        return $this->context->smarty->fetch('module:pagarmeprestashop/views/templates/front/boleto-form.tpl');
    }

}